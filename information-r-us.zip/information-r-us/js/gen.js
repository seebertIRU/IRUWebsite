function nav_adjust(li)
{
	li.addClass('mm-active');
	var ul = li.parent('ul');
	if(ul.attr("id")=="theology-nav") return;
	ul.addClass('mm-show');
	var a_ul = ul.prev('a');
	if(a_ul.hasClass('has-arrow')) a_ul.attr('aria-expanded', 'true').addClass('hierarch');
	nav_adjust(a_ul.parent('li'));
}






