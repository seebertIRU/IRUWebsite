 $(document).ready(function () {
	$(function() {$('#theology-nav').metisMenu({toggle: false}) });
	function reset_nav_position()
	{
		$(function() {$('#nav-container').offset({ top: $('#theology').height()+$(window).scrollTop()})});
		$('div#maincontent table td').css('padding-top', $('#theology').height());
		var h = $('#footer-header #footer.navbar').outerHeight()+100;
		$('#nav-container .margin-bottom').css('margin-top', h);
		$('#row-0').css('margin-bottom', h);
	}
	function nav_toggle(event)
	{
		if(event) event.preventDefault();
		var element = $(this);
		var state = element.attr('state');
		if(state=='off')
		{
			$('#nav-button').removeClass('nav-button-off');
			$('#nav-button').addClass('nav-button-on');
			$('#nav-container').show(700);
			reset_nav_position();		
		}			
		else
		{
			$('#nav-button').removeClass('nav-button-on');
			$('#nav-button').addClass('nav-button-off');
			$('#nav-container').hide(700);
		}
		element.attr('state', (state=='off')?'on':'off');
	}
	$('#nav-button').mouseover(function(){$('#nav-button').removeClass('nav-button-off').addClass('nav-button-on');}).mouseout(function(){$('#nav-button').removeClass('nav-button-on').addClass('nav-button-off');});
	function close_toggle(event)
	{
		if(event) event.preventDefault();
		$('#nav-container').hide(700);
		$('#nav-button').removeClass('nav-button-on').addClass('nav-button-off');
		$('#nav-button').attr('state', 'off');
	}
	
	function font_size(event)
	{
		if(event) event.preventDefault();
		var fs = $('body').css('font-size');
		var lh = $('body').css('line-height');
		fs = fs.substr(0,fs.length - 2);
		lh = lh.substr(0,lh.length - 2);
		lh = lh.substr(0,-1);
		if($(this).attr('id') == 'font-sizing-A')
		{fs++;lh++;}
		else
		{fs--;lh--;}
		$('body').css('font-size', fs+'px');
		$('body').css('line-height', lh+'px');
		$('div#maincontent table td').css('padding-top', $('#theology').height());
	}
	$('#span-nav-button > div >  a').mouseover(function (){
		$(this).find('span').addClass('nav-over');
		//$(this).parent().addClass('nav-over');
		//$(this).parent().parent().addClass('nav-over');
	}).mouseout(function (){
		$(this).find('span').removeClass('nav-over');
		//$(this).parent().removeClass('nav-over');
		//$(this).parent().parent().removeClass('nav-over');
	});

	$('#font-sizing-A').click(font_size);
	$('#font-sizing-a').click(font_size);
	$('#nav-button').click(nav_toggle);
	$('#close-nav').click(close_toggle);
	$('div#maincontent table td').css('padding-top', $('#theology').height());
	$('#font-sizing-div').css('top', $('#theology').height());
	$(window).resize(reset_nav_position);	
	if(!!navigator.userAgent.match(/Version\/[\d\.]+.*Safari/))
	{
		//alert(9);
		$('link#safari-css').attr('href', '/css/general/safari.css');
	}

 });