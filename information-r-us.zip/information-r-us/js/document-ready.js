 $(document).ready(function () {
	$(function() {$('#theology-nav').metisMenu({toggle: false}) });
	//$('#home-element').html('p');
	$(document).on("click", function(e){
	  if( 
		$(e.target).closest("#nav-container").length == 0 &&
		$("#nav-container").hasClass("show") &&
		$(e.target).closest("#nav-hamburger-div").length == 0
	  ){
		//$('#nav-container').removeClass('show');
		$('button.navbar-toggler').click();
		//$('#home-element').html('p');

	  }
	});
		//$('#home-element').html($('.container-fluid').width());
	//alert($('.container-fluid').width());
	//$('#home-element').html($('.container-fluid').width());
 });