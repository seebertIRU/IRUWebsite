<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 	<title>Information-R-US</title>
   <meta name="description" content="Leading SQL Server and Power BI consulting service offering expert solutions for data management, analytics, and visualization. Contact us for tailored SQL Server and Power BI consulting services to optimize your data infrastructure and drive insightful business decisions." />
    <meta name="keywords" content="Operating Environments: Windows Server, Windows Client, Azure, Linux, SQL Server, Azure, Oracle, SQL Lite, MySQL, MariaDB, MongoDB, Denodo, Active Directory, C#, Java, Perl, Python, M, DAX, SQL, PHP, HTML 3.0-5.0, JavaScript, PowerShell, CMD, BASH,  ASP, M, LINQ, C++, Scripting, Procedural, CI/CD, SCRUM, Agile, Waterfall, curl REST
Data Description Schema APIs: JSON, XML, CSV, REST, ODBC, JDBC
Frameworks: Web Forms, Windows Forms, ASP.NET, PowerBI, SSIS, SSAS, Python Database
Software Lifecycle Management Tools: Jira, GIT, Red Hat SQL Tools, Microsoft Project, Gantt Charts, Visio Data Flow Diagraming, Jira, Visual Bugs, Visual Studio IDE
, Office365, Excel, Word, Crystal Reports, PowerBI, Coding Standards, Inventory Management Automation, Data Entry Integrity, Centralized Data Lakes, SQL Server Stored Procedures">
	<meta charset="utf-8">
	<meta name="HandheldFriendly" content="true" />
	<meta name="MobileOptimized" content="320" />
	<meta http-equiv="X-UA-Compatible" content="IE=Edge" />
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1">
	<meta name="viewport" content="shrink-to-fit=yes">
	<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
	<link rel="stylesheet" href="/css/general/base-css/bootstrap.min.css" />
	<link rel="stylesheet" href="/css/general/base-css/font-awesome.min.css">
	<link rel="stylesheet" href="/css/general/base-css/metisMenu.min.css" />
	<link rel="stylesheet" href="/css/general/base-css/prism.css" />
	<link rel="stylesheet" href="/css/general/base-css/animate.css" />
	<link rel="stylesheet" href="/css/general/base-css/noty.css">
	<link rel="stylesheet" href="/css/general/base-css/relax.css">
	<link rel="stylesheet" href="/css/general/base-css/app.css">
	<link rel="stylesheet" href="/css/general/base-css/mm-vertical.css">
	<link rel="stylesheet" href="/css/general/main.css">
	<link rel="stylesheet" href="css/css-override.css">
	<script src="/js/base-js/jquery.3.4.1.min.js"></script>
	<script src="/js/base-js/bootstrap.bundle.min.js"></script>
	<script src="/js/base-js/metisMenu.min.js"></script>
	<script src="/js/base-js/prismjs.js"></script>
	<script src="/js/base-js/noty.js"></script>
	<script src="/js/gen.js" type="text/javascript"></script>
	<script src="/js/document-ready.js"></script>
	<script  type="text/javascript" language="JavaScript">
		$(document).ready(function () {
			var selector = 'ul > li> a[href*="<?= $_SERVER['REQUEST_URI']; ?>"]';
			if($(selector).length) {
				$(selector).addClass('hierarch');
				nav_adjust($(selector).parent());
			}
			
		});	
	</script>
</head>

  </head>    
  <body>

<header id="theology">
	<div class="container-fluid navbar bg-dark box-shadow">
		<div class="container ">
				<h2><span id="theology-title"><a href="/ted/home.php" class="d-flex align-items-center">
				 <span id="alpha"></span>Information-R-US<span id="omega"></span>
				</a></span></h2>
		    </div>
	</div>
</header>
<div id="nav-hamburger-div" class="d-flex align-items-center">
	<button class="navbar-toggler ml-auto navbar-dark" 
			type="button"
			data-toggle="collapse" 
			data-target="#nav-container">
		<span class="navbar-toggler-icon">
	  </span>
	</button>
</div>		
<div class="the-nav container-fluid" >
	 <div class="row">
		<div id="nav-container" class="col-12 navbar-collapse collapse">
			<nav class="sidebar-nav">
			  <ul class="metismenu" id="theology-nav">
				<li class=""><span id="span-home-element"><a id="home-element" href="/ted/home.php">Home</a></span></li>
				<li class="cat"><a class="has-arrow" aria-expanded="false" href="#">Services</a>
					<ul>
						<li><a href="zoom.php">Zoom... | $75/hr</a></li>
						<li><a href="taxes.php">Taxes... | $80/person</a></li>
						<li><a href="win-11.php">WIn 11 Upgrade... | $90/hr</a></li>
						<li><a href="printer.php">Printer Install... | $70/hr</a></li>
						<li><a href="virus.php">VIrus... | $300 flat rate</a></li>
						<li><a href="new-computer.php">New Computer Install... | $100/hr</a></li>
						<li><a href="lan.php">LAN party... | $205/hr</a></li>
						<li><a href="projector.php">Projector Setup... | $50/event</a></li>
						<li><a href="zoom-hybrid.php">Zoom Meeting Hybrid... | $300/event</a></li>
						<li><a href="smb-server.php">Business Server Setup... | $250/hr</a></li>
						<li><a href="custom-sw.php">Custom Softward Engineering... | $100/hr/</a></li>
						<li><a href="w2-consultation.php">W2 Consultation... | $75/hr</a></li>
						<li><a href="sm-retention.php">Small Business Retention... | $150/month/</a></li>
						<li><a href="ft-w2.php">W2 fulltime work... | $145,000/yr/</a></li>
					</ul>
				</li>

		    </ul>
        </nav>
      </div>
    </div>
</div>

<div class="container writing">
<h2>Ted Seeber</h2>
 <?
 include("inc/resume.php");
 ?> 