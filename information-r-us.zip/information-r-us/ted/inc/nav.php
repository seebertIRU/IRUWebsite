<div id="nav-hamburger-div" class="d-flex align-items-center">
	<button class="navbar-toggler ml-auto navbar-dark" 
			type="button"
			data-toggle="collapse" 
			data-target="#nav-container">
		<span class="navbar-toggler-icon">
	  </span>
	</button>
</div>		
<div class="container-fluid" >
	 <div class="row">
		<div id="nav-container" class="col-12 navbar-collapse collapse">
			<nav class="sidebar-nav">
			  <ul class="metismenu" id="theology-nav">
				<li class=""><span id="span-home-element"><a id="home-element" href="/">Home</a></span></li>
				<li class="cat"><a class="has-arrow" aria-expanded="false" href="#">Services</a>
					<ul>
						<li class="sub-cat"><a class="has-arrow sub-cat-a" aria-expanded="false" href="#">The Ages of the World</a>

					<ul>
						<li><a href=".php">Zoom... | $75/hr</a></li>
						<li><a href=".php">Taxes... | $80/person</a></li>
						<li><a href=".php">WIn 11 Upgrade... | $90/hr</a></li>
						<li><a href=".php">Printer Install... | $70/hr</a></li>
						<li><a href=".php">VIrus... | $300 flat rate</a></li>
						<li><a href=".php">New Computer Install... | $100/hr</a></li>
						<li><a href=".php">LAN party... | $205/hr</a></li>
						<li><a href=".php">Projector Setup... | $50/event</a></li>
						<li><a href=".php">Zoom Meeting Hybrid... | $300/event</a></li>
						<li><a href=".php">Business Server Setup... | $250/hr</a></li>
						<li><a href=".php">Custom Software Engineering... | $100/hr/</a></li>
						<li><a href=".php">W2 Consultation... | $75/hr</a></li>
						<li><a href=".php">Small Business Retention... | $150/month/</a></li>
						<li><a href=".php">W2 fulltime work... | $145,000/yr/</a></li>
					</ul>
					</li></ul>
				</li>

		    </ul>
        </nav>
      </div>
    </div>
</div>


