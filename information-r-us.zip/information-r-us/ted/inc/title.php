
<header id="theology">
	<div class="container-fluid navbar bg-dark box-shadow">
		<div class="container ">
				<span id="theology-title"><a href="/" class="d-flex align-items-center">
				  <strong><span id="alpha">|</span>Information-R-Us<span id="omega">|</span></strong>
				</a></span>
		    </div>
	</div>
</header>
