	
	<p>&nbsp;</p>
	<p>Payment Processing pending:</p>
	<p><a href="https://paypal.me/TheodoreSeeber?country.x=US&locale.x=en_US"><img height=128px, width=128px src="https://www.logotypes101.com/logos/80/BD0B2A99B4B93EF6B3F6DB5E555F8548/paypal_me.png" alt="Paypal Me" /></a>
</p>
	<p><div class='seal'>
<script type='text/javascript' src='https://www.rapidscansecure.com/siteseal/siteseal.js?code=65,0C9650BAC544E777EB757BF970FFB74EAFAB6DC2'></script>
</div></p>
<p><img src="payments.png"></p>
	<p><img src="sectigo_trust_seal_lg_140x54"></p>