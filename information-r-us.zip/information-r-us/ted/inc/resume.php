 <header class="resume">
      <div id="resume"  class="container-fluid">
      <div  class="container container-fluid d-flex ">
			  <span><h3>Resume: <a href="http://informationr.us/TMSDIC.docx.pdf">Ted Seeber Resume In PDF</a> &nbsp;&nbsp;| &nbsp;&nbsp;
	Phone: <a href="tel:5033181508">503-318-1508</a> &nbsp;&nbsp;|&nbsp;&nbsp;
	Email: <a href="mailto:seebert42@gmail.com?subject=IRURequest">seebert42@gmail.com</a>
	 </h3></span>
      </div>
    </div>
 
</header>	