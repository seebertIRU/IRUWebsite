
  <header id="theology">
    <div class="navbar navbar-expand-md navbar-dark bg-dark box-shadow">
      <div class="container d-flex justify-content-between" style="justify-content:flex-start!important">
		<a href="#" id="nav-button" state="off">&#8803;</a>
		<a href="/" class="navbar-brand d-flex align-items-center" style="">
          <strong>Theology of the Ages</strong>
        </a>
      </div>
    </div>
  </header>
