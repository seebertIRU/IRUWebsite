<div id="list-border-0">
<div id="list-border">
 <div id="list-overflow">
  <div id="nav-container" class="container">
    <div id="row-0">
    <div class="row">
      <div class="col-md-3">
        <nav class="sidebar-nav">
          <ul class="metismenu" id="theology-nav">
            <li class="">
			<div id="home-div">
              <span id="span-home-element"><a id="home-element" href="/">Home</a></span><span id="span-close-nav"><a id="close-nav" state="off" href="#">X</a></span>
			</div>
            </li>
			<li class="cat"><a class="has-arrow" aria-expanded="false" href="#">The Greater Ages</a>
				<ul>
					<li class="sub-cat"><a class="has-arrow sub-cat-a" aria-expanded="false" href="#">The Ages of the World</a>
						<ul>
							<li><a href="/content/apocalypse/greater-ages/ages/nebudchanezzar-eternal-dream.php">The Abstract World and the Eternal Dream</a></li>
							<li><a href="/content/apocalypse/greater-ages/ages/futurism-or-preterism.php">Futurism, Preterism, or Something Else?</a></li>
							<li><a href="/content/apocalypse/greater-ages/ages/abstract-ages-intro.php">The Abstract World: Introduction</a></li>
							<li><a href="/content/apocalypse/greater-ages/ages/abstract-ages-prefigurement.php">The Abstract World: the Prefiguring Covenant</a></li>
							<li><a href="/content/apocalypse/greater-ages/ages/abstract-ages-preeminent.php">The Abstract World: the Preeminent Ages</a></li>
							<li><a href="/content/apocalypse/greater-ages/ages/abstract-ages-way-of-saint.php">The Abstract World: the Way of the Saint</a></li>
							<li><a href="/content/apocalypse/greater-ages/ages/creation-days-beast-kings.php">The Days of Creation and the Beast</a></li>
							<li><a href="/content/apocalypse/greater-ages/ages/joyful-mysteries-ages-revised.php">The Joyful Mysteries as the Ages</a></li>
							<li><a href="/content/apocalypse/greater-ages/ages/7-unclean-spirits.php">The Unclean Spirits Parable</a></li>
							<li><a href="/content/apocalypse/greater-ages/ages/music-greater-ages.php">Music and the Greater Ages</a></li>
							<li><a href="/content/apocalypse/greater-ages/ages/dragon-woman-millennium.php">The Dragon and the Woman</a></li>
							<li><a href="/content/apocalypse/greater-ages/ages/seven-letters.php">The Apocalypse Seven Letters to the Churches</a></li>
							<li><a href="/content/apocalypse/greater-ages/ages/65th-week.php">Daniel and the 65th Week</a></li>
							<li><a href="/content/apocalypse/greater-ages/ages/noah-and-dove-blasphemy-hs.php">Apocalyptic Blasphemy against the Holy Spirit</a></li>
							<li><a href="/content/apocalypse/greater-ages/ages/fullness-of-time.php">The Fullness of Time</a></li>
							<li><a href="/content/apocalypse/greater-ages/ages/augustine-and-the-1000-years.php">Augustine and the 1000 years</a></li>
							<li><a href="/content/apocalypse/greater-ages/ages/pentecostal-donatism.php">Pentecostalism and Donatism</a></li>
						</ul>
					</li>
					<li class="sub-cat"><a class="has-arrow sub-cat-a" aria-expanded="false" href="#">The Mystery of the Conversion of the Jews</a>
						<ul>
							<li><a href="/content/apocalypse/greater-ages/jewish-conversion/why-will-jews-convert.php">Why will the Jews Convert?</a></li>
							<li><a href="/content/apocalypse/greater-ages/jewish-conversion/holy-family-finding-in-temple.php">The Finding in the Temple</a></li>
							<li><a href="/content/apocalypse/greater-ages/jewish-conversion/fish-pork-maccabees.php">Fish, Pork, and Maccabees</a></li>
							<li><a href="/content/apocalypse/greater-ages/jewish-conversion/prodigal-son-parable.php">Prodigal Son</a></li>
							<li><a href="/content/apocalypse/greater-ages/jewish-conversion/mary-magdalene.php">Mary Magdelene</a></li>
						</ul>
					</li>
				</ul>
			</li>
			<li class="cat"><a class="has-arrow" aria-expanded="false" href="#">Ecclesiology</a>
				<ul>
					<li class="sub-cat"><a class="has-arrow sub-cat-a" aria-expanded="false" href="#">Ecclesiological Truth and Doctrinal History</a>
						<ul>
							<li><a href="/content/apocalypse/ecclesiology/truth/pyramid-scandal.php">Scandal, the Mystical Catholic Pyramid</a></li>
							<li><a href="/content/apocalypse/ecclesiology/truth/theology-christs-crucified-feet.php">Theology of Christ's Crucified Feet</a></li>
							<li><a href="/content/apocalypse/ecclesiology/truth/music-doctrinal-history.php">Music and Doctrinal History</a></li>
						</ul>
					</li>
					<li class="sub-cat"><a class="has-arrow sub-cat-a" aria-expanded="false" href="#">The Sacramental Mystery</a>
						<ul>	
							<li><a href="/content/apocalypse/ecclesiology/grace/5-loaves-two-fish.php">5 Loaves and 2 Fish as the 7 Sacraments</a></li>
							<li><a href="/content/apocalypse/ecclesiology/grace/3-loaves-initiation.php">3 Loaves as the Sacraments of Iniitiation</a></li>
							<li><a href="/content/apocalypse/ecclesiology/grace/theology-christs-crucified-hands.php">Theology of Christ's Crucified Hands</a></li>
							<li><a href="/content/apocalypse/ecclesiology/grace/finger-parts-sacraments.php">Fingers' Phalanges as Sacraments</a></li>
							<li><a href="/content/apocalypse/ecclesiology/grace/loaves-stones-eggs-scorpions.php">Loaves, Eggs, Fish, Scorpions, and Serpents</a></li>
							<li><a href="/content/apocalypse/ecclesiology/grace/music-sacraments.php">Music and the Sacraments</a></li>
							<li><a href="/content/apocalypse/ecclesiology/grace/devil-counterfeit-heaven.php">Devil's Counterfeit of Heaven</a></li>
							<li><a href="/content/apocalypse/ecclesiology/grace/temple-tax-coin.php">Temple Tax Coin</a></li>
						</ul>
					</li>
					<li class="sub-cat"><a class="has-arrow sub-cat-a" aria-expanded="false" href="#">Miscellaneous</a>
						<ul>	
							<li><a href="/content/apocalypse/ecclesiology/trumpets-three-great-woes.php">Protestantism and More in the Apocalypse</a></li>
							<li><a href="/content/apocalypse/ecclesiology/unforgiving-servant-numbers.php">Unforgiving Servant and Mystical Numbers</a></li>
							<li><a href="/content/apocalypse/ecclesiology/woman-at-well.php">Woman at Well and Ecclesiology</a></li>
							<li><a href="/content/apocalypse/ecclesiology/ot-north.php">OT Schism and NT Division</a></li>
							<li><a href="/content/apocalypse/ecclesiology/ot-north-ii.php">OT Schism and NT Division II</a></li>
							<li><a href="/content/apocalypse/ecclesiology/communism-fascism-extremes.php">Communism, Fascism, and Christian Extremes</a></li>
						</ul>
					</li>
				</ul>
			</li>
			<li class="cat"><a class="has-arrow" aria-expanded="false" href="#">Intermediate Time</a>
				<ul>
					<li><a href="/content/apocalypse/intermediate-time/christian-disunity-two-witnesses.php">The Two Witnesses and Christian Disunity</a></li>
					<li><a href="/content/apocalypse/intermediate-time/jewish-diaspora-fullness-gentiles-jewish-conversion.php">The Jewish Diaspora</a></li>
					<li><a href="/content/apocalypse/intermediate-time/fatima-north-south-east-west.php">Fatima, East, West, Communism and Relativism</a></li>
					<li><a href="/content/apocalypse/intermediate-time/nt-pharisee-new-eve.php">The NT Pharises and the New Eve</a></li>
					<li><a href="/content/apocalypse/intermediate-time/how-many-apostasies.php">How Many Apostasies?</a></li>
					<li><a href="/content/apocalypse/intermediate-time/just-another-opposition.php">Just Another Opposition?</a></li>
					<li><a href="/content/apocalypse/intermediate-time/church-is-final-age-but.php">Church is Final Age, But</a></li>
					<li><a href="/content/apocalypse/intermediate-time/crucified-body-chastisement-extremes.php">The Crucified Body Imaging Chastisement</a></li>
					<li><a href="/content/apocalypse/intermediate-time/hemorrhaging-woman-little-girl.php">Hemorrhaging Woman, Little Girl</a></li>
				</ul>
			</li>
			<li class="cat"><a class="has-arrow" aria-expanded="false" href="#">Idealism</a>
				<ul>
					<li><a href="/content/apocalypse/idealism/false-prophet.php">Baptism, Marriage, and the False Prophet</a></li>
					<li><a href="/content/apocalypse/idealism/seal-of-god-mark-of-beast.php">The 144,000 and the Mark of the Beast</a></li>
					<li><a href="/content/apocalypse/idealism/armageddon-kings-from-east.php">Armageddon, the Kings from the East</a></li>
					<li><a href="/content/apocalypse/idealism/pilate-herod-fall.php">Pilate and Herod, Images of the Fall</a></li>
							<li><a href="/content/apocalypse/ecclesiology/truth/daniel-7-ten-commandments.php">Daniel 7 and the 10 Commandments</a></li>
				</ul>
			</li>
			<li class="cat"><a class="has-arrow" aria-expanded="false" href="#">General</a>
				<ul>
					<li><a href="/content/general/sex-abc.php">Artificial Birth Control</a></li>
					<li><a href="/content/general/my-reversion-story.php">My Reversion Story</a></li>
					<li><a href="/content/general/darth-vader-lust-hell.php">Darth Vader, Lust, and Hell</a></li>
					<li><a href="/content/general/outside-church-no-salvation.php">Outside Church, No Salvation</a></li>
					<li><a href="/content/general/karate-kid-calvinism.php">The Karate Kid and Calvinism</a></li>
					<li><a href="/content/general/annihilationism.php">Annihilationism</a></li>
				</ul>
			</li>

          </ul>
        </nav>
      </div>
    </div>
    </div>
	<div class="margin-bottom"><p>&nbsp;</p></div>
  </div>
</div>
</div>  
</div>  
  

