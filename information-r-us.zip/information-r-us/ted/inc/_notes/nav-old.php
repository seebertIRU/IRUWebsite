<div id="nav-hamburger-div" class="d-flex align-items-center">
	<button class="navbar-toggler ml-auto navbar-dark" 
			type="button"
			data-toggle="collapse" 
			data-target="#nav-container">
		<span class="navbar-toggler-icon">
	  </span>
	</button>
</div>		
<div id="nav-container" class=" navbar-collapse collapse">
    <div class="row">
      <div class="col-md-3">
        <nav class="sidebar-nav">
          <ul class="metismenu" id="theology-nav">
            <li class=""><span id="span-home-element"><a id="home-element" href="/">Home</a></span></li>
			<li><a href="/content/excerpts.php">Excerpts</a></li>
			<li class="cat"><a class="has-arrow" aria-expanded="false" href="#">The Greater Ages</a>
				<ul>
					<li class="sub-cat"><a class="has-arrow sub-cat-a" aria-expanded="false" href="#">The Ages of the World</a>
						<ul>
							<li><a href="/content/apocalypse/greater-ages/ages/introduction.php">Theology of the Ages: Introduction</a></li>
							<li class="sub-cat"><a class="has-arrow sub-cat-a" aria-expanded="false" href="#">The Abstract World</a>
								<ul>
									<li><a href="/content/apocalypse/greater-ages/ages/nebudchanezzar-eternal-dream.php">The Abstract World and the Eternal Dream</a></li>
									<li><a href="/content/apocalypse/greater-ages/ages/abstract-ages-intro.php">The Abstract World: Prelinimary Considerations</a></li>
									<li><a href="/content/apocalypse/greater-ages/ages/abstract-ages-prefigurement.php">The Abstract World: the Prefiguring Covenant</a></li>
									<li><a href="/content/apocalypse/greater-ages/ages/abstract-ages-preeminent.php">The Abstract World: the Preeminent Ages</a></li>
									<li><a href="/content/apocalypse/greater-ages/ages/abstract-ages-way-of-saint.php">The Abstract World: the Way of the Saint</a></li>
								</ul>
							</li>
							<li class="sub-cat"><a class="has-arrow sub-cat-a" aria-expanded="false" href="#">Scriptural Analogies of the Greater Ages</a>
								<ul>
									<li><a href="/content/apocalypse/greater-ages/ages/creation-days-beast-kings.php">The Days of Creation and the Beast</a></li>
									<li><a href="/content/apocalypse/greater-ages/ages/joyful-mysteries-ages-revised.php">The Joyful Mysteries as the Ages</a></li>
									<li><a href="/content/apocalypse/greater-ages/ages/7-unclean-spirits.php">The Unclean Spirits Parable</a></li>
									<li><a href="/content/apocalypse/greater-ages/ages/music-greater-ages.php">Music and the Greater Ages</a></li>
									<li><a href="/content/apocalypse/greater-ages/ages/65th-week.php">Daniel and the 65th Week</a></li>
									<li><a href="/content/apocalypse/greater-ages/ages/noah-and-dove-blasphemy-hs.php">Noah and the Dove</a></li>
								</ul>
							</li>
						</ul>
					</li>
					<li class="sub-cat"><a class="has-arrow sub-cat-a" aria-expanded="false" href="#">The Mystery of the Conversion of the Jews</a>
						<ul>
							<li><a href="/content/apocalypse/greater-ages/jewish-conversion/why-will-jews-convert.php">Why will the Jews Convert?</a></li>
							<li><a href="/content/apocalypse/greater-ages/jewish-conversion/holy-family-finding-in-temple.php">The Finding in the Temple</a></li>
							<li><a href="/content/apocalypse/greater-ages/jewish-conversion/fish-pork-maccabees.php">Fish, Pork, and Maccabees</a></li>
							<li><a href="/content/apocalypse/greater-ages/jewish-conversion/prodigal-son-parable.php">Prodigal Son</a></li>
							<li><a href="/content/apocalypse/greater-ages/jewish-conversion/mary-magdalene.php">Mary Magdelene</a></li>
						</ul>
					</li>
				</ul>
			</li>
			<li class="cat"><a class="has-arrow" aria-expanded="false" href="#">Ecclesiology</a>
				<ul>
					<li class="sub-cat"><a class="has-arrow sub-cat-a" aria-expanded="false" href="#">Ecclesiological Truth and Doctrinal History</a>
						<ul>
							<li><a href="/content/apocalypse/ecclesiology/truth/pyramid-scandal.php">Scandal, the Mystical Catholic Pyramid</a></li>
							<li><a href="/content/apocalypse/ecclesiology/truth/theology-christs-crucified-feet.php">Theology of Christ's Crucified Feet</a></li>
							<li><a href="/content/apocalypse/ecclesiology/truth/music-doctrinal-history.php">Music and Doctrinal History: the Ironic Scale of Ascending Sorrow</a></li>
						</ul>
					</li>
					<li class="sub-cat"><a class="has-arrow sub-cat-a" aria-expanded="false" href="#">The Sacramental Mystery</a>
						<ul>	
							<li class="sub-cat"><a class="has-arrow sub-cat-a" aria-expanded="false" href="#">The 5, the 2, the 20,000, and the 10,000</a>
								<ul>
									<li><a href="/content/apocalypse/ecclesiology/grace/5-loaves-two-fish.php">5 Loaves and 2 Fish: the 7 Sacraments</a></li>
									<li><a href="/content/apocalypse/ecclesiology/grace/theology-christs-crucified-hands.php">Theology of Christ's Crucified Hands</a></li>
									<li><a href="/content/apocalypse/ecclesiology/grace/finger-parts-sacraments.php">Fingers' Phalanges as Sacraments</a></li>
									<li><a href="/content/apocalypse/ecclesiology/grace/music-sacraments.php">Music in the Sacraments: the Ironic Scale of Descending Joy</a></li>
									<li><a href="/content/apocalypse/ecclesiology/unforgiving-servant-numbers.php">Unforgiving Servant and Mystical Numbers</a></li>
								</ul>
							</li>
							<li class="sub-cat"><a class="has-arrow sub-cat-a" aria-expanded="false" href="#">Scorpions, Serpents and the Fifth Trumpet</a>
								<ul>
									<li><a href="/content/apocalypse/ecclesiology/grace/loaves-stones-eggs-scorpions.php">Loaves, Eggs, Fish, Scorpions, and Serpents</a></li>
								</ul>
							</li>
						</ul>
					</li>
					<li class="sub-cat"><a class="has-arrow sub-cat-a" aria-expanded="false" href="#">Conservatism, Liberalism and Christian Division</a>
						<ul>	
							<li><a href="/content/apocalypse/ecclesiology/grace/3-loaves-initiation.php">3 Loaves as the Sacraments of Iniitiation</a></li>
							<li><a href="/content/apocalypse/ecclesiology/female-diaconate.php">The "Female Diaconate" and the Woman at the Well</a></li>
							<li><a href="/content/apocalypse/ecclesiology/communism-fascism-extremes.php">Communism, Fascism, and Christian Extremes</a></li>
						</ul>
					</li>
				</ul>
			</li>
			<li class="cat"><a class="has-arrow" aria-expanded="false" href="#">Intermediate Time</a>
				<ul>
					<li><a href="/content/apocalypse/intermediate-time/christian-disunity-two-witnesses.php">The Two Witnesses and Christian Disunity</a></li>
					<li><a href="/content/apocalypse/intermediate-time/hemorrhaging-woman-little-girl.php">Hemorrhaging Woman, Little Girl</a></li>
					<li><a href="/content/apocalypse/intermediate-time/crucified-body-chastisement-extremes.php">The Crucified Body Imaging Chastisement</a></li>
					<li><a href="/content/apocalypse/intermediate-time/jewish-diaspora-fullness-gentiles-jewish-conversion.php">The Jewish Diaspora</a></li>
					<li><a href="/content/apocalypse/intermediate-time/fatima-north-south-east-west.php">Fatima, East, West, Communism and Relativism</a></li>
					<li><a href="/content/apocalypse/intermediate-time/nt-pharisee-new-eve.php">The NT Pharises and the New Eve</a></li>
				</ul>
			</li>
			<li class="cat"><a class="has-arrow" aria-expanded="false" href="#">Idealism</a>
				<ul>
					<li><a href="/content/apocalypse/idealism/false-prophet.php">Baptism, Marriage, and the False Prophet</a></li>
					<li><a href="/content/apocalypse/idealism/seal-of-god-mark-of-beast.php">The 144,000 and the Mark of the Beast</a></li>
					<li><a href="/content/apocalypse/idealism/armageddon-kings-from-east.php">Armageddon, the Kings from the East</a></li>
					<li><a href="/content/apocalypse/idealism/pilate-herod-fall.php">Pilate and Herod, Images of the Fall</a></li>
				</ul>
			</li>
			<li class="cat"><a class="has-arrow" aria-expanded="false" href="#">Synthesis: Putting it all Together</a>
				<ul>
					<li><a href="/content/apocalypse/ecclesiology/trumpets-three-great-woes.php">Protestantism and More in the Apocalypse</a></li>
					<li><a href="/content/apocalypse/ecclesiology/grace/devil-counterfeit-heaven.php">Devil's Counterfeit of Heaven</a></li>
					<li><a href="/content/apocalypse/greater-ages/ages/dragon-woman-millennium.php">The Dragon and the Woman</a></li>
					<li><a href="/content/apocalypse/greater-ages/ages/pentecostal-donatism.php">Pentecostalism and Donatism</a></li>
					<li><a href="/content/apocalypse/greater-ages/ages/seven-letters.php">The Apocalypse Seven Letters to the Churches</a></li>
				</ul>
			</li>
          </ul>
        </nav>
      </div>
    </div>
  </div>


