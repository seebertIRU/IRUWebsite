
  <header id="theology">
    <div class="navbar navbar-expand-md navbar-dark bg-dark box-shadow">
      <div id="theology-div" class="container  justify-content-between" style="justify-content:space-between;">
		<span id="span-nav-button">
		    <div>
				<a href="#"  class="nav-button nav-button-off" state="off"><span>&Alpha;</a></span>
				<span id="nav-int"><a href="#"  class="nav-button nav-button-off" state="off">&sum;</a></span>
				<span><a href="#" class="nav-button nav-button-off" state="off">&Omega;</a></span>
				<span><a href="#" id="nav-button"  class="nav-button nav-button-off" state="off">&nbsp;&raquo;</a></span>
			</div>
		</span>
		<span id="span-title"><a href="/" class="d-flex align-items-center">
          <strong>Theology of the Ages</strong>
        </a></span>
		<span id="font-sizing-div">
			<a href="#" id="font-sizing-A">A</a> 	
			<a href="#" id="font-sizing-a">a</a>	
		</span>		

      </div>
    </div>
  </header>
