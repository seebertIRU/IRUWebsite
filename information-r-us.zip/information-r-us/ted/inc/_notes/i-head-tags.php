<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title><?= $title;?></title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge" />

	<meta name="viewport" content="width=device-width">
	<meta name="viewport" content="initial-scale=1">
	<meta name="viewport" content="maximum-scale=2">
	<meta name="viewport" content="shrink-to-fit=yes">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap/dist/css/bootstrap.min.css" />
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://unpkg.com/metismenu/dist/metisMenu.min.css" />
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/prismjs/themes/prism.css" />
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/animate.css" />
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/noty/lib/noty.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/noty/lib/themes/relax.css">

	<link rel="stylesheet" href="/js/metismenu/demo/assets/css/app.css">
	<link rel="stylesheet" href="/js/metismenu/demo/assets/css/mm-vertical.css">

	<script src="https://cdn.jsdelivr.net/npm/jquery"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
	<script src="https://unpkg.com/metismenu"></script>
	<script src="https://cdn.jsdelivr.net/npm/prismjs"></script>
	<script src="https://cdn.jsdelivr.net/npm/noty"></script>
    <script src="/js/metismenu/demo/assets/js/mm-vertical.js" charset="utf-8"></script>
	<link href="/css/general/main.css" type="text/css" rel="stylesheet" >
	<script src="/js/gen.js" type="text/javascript" language="JavaScript"></script>
	<script language="javascript" type="text/javascript" src="/js/document-ready.js"></script>
	<script  type="text/javascript" language="JavaScript">
		$(document).ready(function () {
			//alert('<?= $target;?>');
			nav_adjust($('ul > li > a[href*="<?= $target;?>"]').parent());
		});	
	</script>

</head>
