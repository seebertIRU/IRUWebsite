
  <header id="theology">
    <div class="navbar navbar-expand-md navbar-dark bg-dark box-shadow">
      <div id="theology-div" class="container  justify-content-between" style="justify-content:space-between;">
		<span id="span-nav-button">
		    <div>
				<a href="#" id="nav-button" class="nav-button nav-button-off" state="off" alt="Table of Conents Navigation&#13;Click to Show&#13;Click again to Hide" title="Table of Conents Navigation&#13;Click to Show&#13;Click again to Hide">
					<span>&Alpha;</span>
					<span id="nav-int">&sum;</span>
					<span>&Omega;</span>
					<span id="nav-to-enlarge">&nbsp;&rtrif;</span>
				</a>
			</div>
		</span>
		<span id="span-title"><a href="/" class="d-flex align-items-center" alt="Home Page" title="Home Page">
          <strong>Theology of the Ages</strong>
        </a></span>
		<span id="font-sizing-div">
			<a href="#" id="font-sizing-A" alt="Enlarge Font" title="Enlarge Font">A</a> 	
			<a href="#" id="font-sizing-a" alt="Diminish Font" title="Diminish Font">a</a>	
		</span>		

      </div>
    </div>
  </header>
