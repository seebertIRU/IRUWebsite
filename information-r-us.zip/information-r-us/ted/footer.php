<header id="footer-header">
    <div id="footer" class="container-fluid navbar navbar-expand-md navbar-dark bg-dark box-shadow">
      <div  class="container container-fluid d-flex ">
			  <span>All Rights Reserved, Ted Seeber | Information-R-US</span> 
      </div>
    </div>
 </header>

</body>
<script>'undefined'=== typeof _trfq || (window._trfq = []);'undefined'=== typeof _trfd && (window._trfd=[]),_trfd.push({'tccl.baseHost':'secureserver.net'},{'ap':'cpsh'},{'server':'a2plcpnl0406'},{'dcenter':'a2'},{'cp_id':'1960972'},{'cp_cache':''},{'cp_cl':'6'}) // Monitoring performance to make your website faster. If you want to opt-out, please contact web hosting support.</script><script src='https://img1.wsimg.com/traffic-assets/js/tccl.min.js'></script>
</html>
 