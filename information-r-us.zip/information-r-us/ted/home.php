
<?
include("head.php");
?>


<p>I am Ted Seeber, a Senior Data Architect Engineer with 20 years of experience in the Microsoft Stack.I help small businesses with full stack development from database schema design up through the user interface.  I specialize in data warehousing and reporting, but I can be an asset on any project. I am also willing to offer online and local tech support to home users.</p>
<p class="reopen">We are reopening at a date to be announced!  See the list of available services below!<br/><br/>I offer home and small business IT services in the Northern Willamette Valley 	at the following rates, minimum 1 hour:</p>
<h2>Services</h2>

	<table>
		<tr><th class="price">Price</th><th class="description">Description</th></tr>
		<tr><td>$75/hr</td><td>Zoom tech support and computer lessons.  I will create a meeting for us on my account</td></tr>
		<tr><td>$80/person</td><td>learn to do your own taxes for free in future years, for those currently filing 1040EZ, in a half hour appointment</td></tr>
		<tr><td>$90/hr</td><td>Upgrade to Windows 11</td></tr>
		<tr><td>$70/hr</td><td>Printer Install</td></tr>
		<tr><td>$300 flat rate</td><td>Virus Detection and Elimination Service</td></tr>
		<tr><td>$100/hr</td><td>New Computer Install with Freeware Install</td></tr>
		<tr><td>$250/hr</td><td>LAN party</td></tr>
		<tr><td>$50/event</td><td>Set Up projector, sound, and tear down</td></tr>
		<tr><td>$300/event</td><td>Hybrid meeting hosted on Zoom with phone call-in and projected/HDMI powerpoint</td></tr>
		<tr><td>$250/hr</td><td>Set up small business server</td></tr>
		<tr><td>$100/hr</td><td>Custom software engineering for your small business</td></tr>
		<tr><td>$75/hr</td><td>W2 consulting - your company handles payroll and taxes</td></tr>
		<tr><td>$150/month </td><td>Put me on retainer for priority service for your small business.</td></tr>
		<tr><td>$145,000/yr</td><td>W2 full time work that will cause me to close Information-R-Us as long as the job lasts.  Most recently, Intel did this from September 2017 to March 2024</td></tr>
	</table><br />

 <?
 include("inc/payment.php");
 ?> 
<p></p>
</div>
 <?
 include("footer.php");
 ?> 
  