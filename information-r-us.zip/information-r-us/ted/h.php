<?
include("head.php");
?>
<div class="container writing">
<h2>Ted Seeber</h2>
<h3>Test</h3>
<p>Service Description Coming Soon!</p>
 <?
 include("inc/resume.php");
 ?> 
</div>
 <?
 include("footer.php");
 ?> 
  