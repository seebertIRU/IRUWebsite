
<? include("head.php"); ?>


<h3>LAN party</h3>
<p>Service Description Coming Soon!</p>
 

  
</div>
 
 <? include("footer.php"); ?>
  
  