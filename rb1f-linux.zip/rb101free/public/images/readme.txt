This folder is where Run BASIC renders public graphic files
